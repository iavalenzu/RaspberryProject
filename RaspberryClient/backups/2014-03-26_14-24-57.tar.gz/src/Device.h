/* 
 * File:   Device.h
 * Author: Ismael
 *
 * Created on 13 de marzo de 2014, 10:14 PM
 */

#ifndef DEVICE_H
#define	DEVICE_H

class Device {
public:
    Device();
    Device(const Device& orig);
    virtual ~Device();
private:

};

#endif	/* DEVICE_H */

