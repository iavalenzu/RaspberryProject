/* 
 * File:   ConnectionSSL.h
 * Author: Ismael
 *
 * Created on 16 de marzo de 2014, 01:54 PM
 */

#ifndef CONNECTIONSSL_H
#define	CONNECTIONSSL_H

class ConnectionSSL {
public:
    ConnectionSSL();
    ConnectionSSL(const ConnectionSSL& orig);
    virtual ~ConnectionSSL();
private:

};

#endif	/* CONNECTIONSSL_H */

