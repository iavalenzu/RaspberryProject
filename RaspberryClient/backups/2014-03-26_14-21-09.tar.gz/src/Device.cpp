/* 
 * File:   Device.cpp
 * Author: Ismael
 * 
 * Created on 13 de marzo de 2014, 10:14 PM
 */

#include "Device.h"

Device::Device() {
}

Device::Device(const Device& orig) {
}

Device::~Device() {
}

