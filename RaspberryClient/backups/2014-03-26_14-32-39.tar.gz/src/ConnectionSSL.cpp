/* 
 * File:   ConnectionSSL.cpp
 * Author: Ismael
 * 
 * Created on 16 de marzo de 2014, 01:54 PM
 */

#include "ConnectionSSL.h"

ConnectionSSL::ConnectionSSL() {
}

ConnectionSSL::ConnectionSSL(const ConnectionSSL& orig) {
}

ConnectionSSL::~ConnectionSSL() {
}

